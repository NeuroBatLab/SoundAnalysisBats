function PlayCallfkt(action)
global PlayerMic FS Raw_wave_nn vv;

switch action
    
    case 'PlayMic'
        play(PlayerMic)
        pause(length(Raw_wave_nn)/FS +1)
        pause(0.1)
    case 'PlayLog1'
       [Player]=getplaylogger(1,vv);
        play(Player)
        pause(length(Raw_wave_nn)/FS +1)
    case 'PlayLog2'
        [Player]=getplaylogger(2,vv);
        play(Player)
        pause(length(Raw_wave_nn)/FS +1)
    case 'PlayLog3'
        [Player]=getplaylogger(3,vv);
        play(Player)
        pause(length(Raw_wave_nn)/FS +1)
    case 'PlayLog4'
        [Player]=getplaylogger(4,vv);
        play(Player)
        pause(length(Raw_wave_nn)/FS +1)
    case 'PlayLog5'
        [Player]=getplaylogger(5,vv);
        play(Player)
        pause(length(Raw_wave_nn)/FS +1)
    case 'PlayLog6'
        [Player]=getplaylogger(6,vv);
        play(Player)
        pause(length(Raw_wave_nn)/FS +1)
    case 'PlayLog7'
        [Player]=getplaylogger(7,vv);
        play(Player)
        pause(length(Raw_wave_nn)/FS +1)
    case 'PlayLog8'
        [Player]=getplaylogger(8,vv);
        play(Player)
        pause(length(Raw_wave_nn)/FS +1)
        
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Player]=getplaylogger(LogN,vv)
global Piezo_wave Fns_AL VolDenominatorLogger Piezo_FS;
Player= audioplayer((Piezo_wave.(Fns_AL{LogN}){vv}-...
    nanmean(Piezo_wave.(Fns_AL{LogN}){vv}))/(VolDenominatorLogger*nanstd(Piezo_wave.(Fns_AL{LogN}){vv})), ...
    Piezo_FS.(Fns_AL{LogN})(vv));
