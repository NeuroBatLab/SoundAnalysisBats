function init_who_calls_playless(Raw_dir, Loggers_dir, Date, ExpStartTime, MergeThresh, Manual,UseOld,CheckMicChannel, varargin)

global VolDenominatorLogger VolFactorMic Working_dir Manual MergeThresh;
global Working_dir_read Working_dir_write DataFiles Factor_RMS_Mic;
global Force_Save_onoffsets_mic SaveFileType CheckMicChannel;
global Date ExpStartTime df DataFile Nvocs MeanStdAmpRawExtract;
global PreviousFile Working_dir_write Date ExpStartTime df MergeThresh vv;
global IndVocStartRaw_merged IndVocStopRaw_merged IndVocStartPiezo_merged;
global IndVocStopPiezo_merged IndVocStartRaw IndVocStopRaw IndVocStartPiezo;
global IndVocStopPiezo IndVocStart_all IndVocStop_all RMSRatio_all RMSDiff_all;
global MicError PiezoError MicErrorType PiezoErrorType DataFile Raw_wave;
global sos_raw_band_listen FS minvv maxvv Nvoc UseOld Loggers_dir;
global sos_raw_band BandPassFilter Piezo_wave AudioLogs Piezo_FS DiffRMS RMSLow VocFilename;
global Fns_AL Consecutive_binsMic Consecutive_binsPiezo Factor_RMS_low Factor_AmpDiff;
global DB_noise FHigh_spec FHigh_spec_Logger Fhigh_power Fs_env;
global evalLog1h evalLog2h evalLog3h evalLog4h evalLog5h;
global evalLog6h evalLog7h evalLog8h leftPloth;


% optional parameter: Factor_RMS_Mic, Factor by which the RMS of the
% band-pass filtered baseline signal is multiplied to obtained the
% threshold of vocalization detection on Microphone
VolDenominatorLogger=5;
VolFactorMic=0.5;
pnames = {'Factor_RMS_Mic','Working_dir','Force_Save_onoffsets_mic','SaveFileType'};
dflts  = {3,Loggers_dir,0,'pdf'};
[Factor_RMS_Mic,Working_dir,Force_Save_onoffsets_mic,SaveFileType] = internal.stats.parseArgs(pnames,dflts,varargin{:});

if nargin<8
    CheckMicChannel = 0;
end

if nargin<7
    UseOld = 0;
end
if nargin<6
    Manual=0;
end
if nargin<5
    % any 2 detected call spaced by less than MergeThresh ms are merge
    MergeThresh = 500; 
end


Working_dir_read = fullfile(Working_dir, 'read');
Working_dir_write = fullfile(Working_dir, 'write');

if ~strcmp(Loggers_dir,Working_dir) && (~exist(Working_dir,'dir') || ~exist(Working_dir_read,'dir') || ~exist(Working_dir_write,'dir'))
    mkdir(Working_dir)
    mkdir(Working_dir_read)
    mkdir(Working_dir_write)
elseif strcmp(Loggers_dir,Working_dir)
    Working_dir_read = Loggers_dir;
    Working_dir_write = Loggers_dir;
end
DataFiles = dir(fullfile(Loggers_dir, sprintf('%s_%s_VocExtractData*.mat', Date, ExpStartTime)));

if isempty(DataFiles)
    warning('Vocalization data were not extracted by get_logger_data_voc.m')
else
    % select the correct files
    Gdf = zeros(length(DataFiles),1);
    for df=1:length(DataFiles)
        if length(strfind(DataFiles(df).name, '_'))==2
            Gdf(df)=1;
        end
    end
    DataFiles = DataFiles(logical(Gdf));
    % gather File indices to reorder them
    IndDataFiles = nan(length(DataFiles),1);
    for nfile = 1:length(DataFiles)
        IndData = strfind(DataFiles(nfile).name, 'Data') + length('Data');
        IndDot = strfind(DataFiles(nfile).name, '.') - 1;
        IndDataFiles(nfile) = str2double(DataFiles(nfile).name(IndData:IndDot));
    end
    [~,AscendOrd] = sort(IndDataFiles);
    DataFiles = DataFiles(AscendOrd);
    load(fullfile(Raw_dir, sprintf('%s_%s_VocExtractTimes.mat', Date, ExpStartTime)), 'MeanStdAmpRawExtract','Voc_filename')
    Nvoc_all = length(Voc_filename);
    DataFile = fullfile(DataFiles(1).folder, DataFiles(1).name);
    load(DataFile, 'VocMaxNum')
    if ~exist('VocMaxNum','var')
        VocMaxNum=1000;
    end
    if Nvoc_all>VocMaxNum
        Nvocs = [0 VocMaxNum:VocMaxNum:Nvoc_all (floor(Nvoc_all/VocMaxNum)*VocMaxNum+rem(Nvoc_all,VocMaxNum))];
    else
        Nvocs = [0 Nvoc_all];
    end
    check=1;
    df=1;
    while check   
        
        %% Identify sound elements in each vocalization extract and decide of the vocalizer
        % Output corresponds to onset and offset indices of each vocal element in
        % sound section for each vocalizing logger. A cell array of length the
        % number of sound sections identified by voc_localize or
        % voc_localize_operant. For IndVocStartRaw_merged each cell contains the onset/offset samples of each vocal element in the sound section.
        % For IndVocStartPiezo_merged each cell is a cell array of size the number of
        % audio-loggers where each cell contains the onset or offset sample of
        % individual vocal element emitted by the respective audio-loggers. Note
        % that for both these variables, vocal elements that are within MergeThresh
        % ms were merged in a single vocal element.
        %
        % Run a time window of duration 2 ms to identify who is vocalizing
        % create 2 signals for the logger, one high pass filtered above 5kHz
        % and the other one low pass filtered at 5kHz. The vocalizer will have
        % the highest energy of all vocalizers and will have more energy in the
        % lower compare to higher filtered signal
        
        Nvoc = Nvocs(df+1) - Nvocs(df);
        DataFile = fullfile(DataFiles(df).folder, DataFiles(df).name);
        
        PreviousFile = fullfile(Working_dir_write, sprintf('%s_%s_VocExtractData%d_%d.mat', Date, ExpStartTime, df,MergeThresh));
        if ~isfile(PreviousFile)
            PreviousFile = fullfile(Working_dir_write, sprintf('%s_%s_VocExtractData_%d.mat', Date, ExpStartTime,MergeThresh));
        end
        if ~isempty(dir(PreviousFile)) && UseOld
            load(PreviousFile, 'IndVocStartRaw_merged', 'IndVocStopRaw_merged',...
                'IndVocStartPiezo_merged', 'IndVocStopPiezo_merged', ...
                'IndVocStart_all', 'IndVocStop_all','IndVocStartRaw',...
                'IndVocStopRaw', 'IndVocStartPiezo', 'IndVocStopPiezo',...
                'IndVocStart_all', 'IndVocStop_all','RMSRatio_all','RMSDiff_all',...
                'vv','MicError','PiezoError','MicErrorType','PiezoErrorType');
            if ~exist('vv','var') % There is no previous data but just data regarding piezo numbers and bats_ID
                vv=1;
            end
            
        else
            vv=1;
        end
        
        % Check if that set of vocalizations was alread fully completed
        if vv==Nvoc
            % All done
            df=df+1;
            vv=1;
        else
            check=0;
            if ~strcmp(Working_dir_write,Loggers_dir) && ~isfile(fullfile(Working_dir_read,DataFiles(df).name))
                fprintf(1,'Bringing data locally from the server\n')
                [s,m,e]=copyfile(DataFile, Working_dir_read, 'f');
                if ~s
                    fprintf(1,'File transfer did not occur correctly\n')
                    keyboard
                else
                    DataFile = fullfile(Working_dir_read,DataFiles(df).name);
                end
            end
            load(DataFile,'Raw_wave')
            if Nvoc ~= length(Raw_wave)
                warning('Looks like there might be an issue there!! Check variables!!')
                keyboard
            end
            if Nvoc<=100
                minvv = 1;
                maxvv = Nvoc;
                load(DataFile,'Piezo_wave', 'AudioLogs',   'Piezo_FS',  'FS', 'DiffRMS', 'RMSLow','VocFilename');
            else % often problem of memory, we're going to chunck file loading
                if ~mod(vv,100)
                    minvv=floor((vv-1)/100)*100 +1;
                    maxvv=ceil(vv/100)*100;
                else
                    minvv = floor(vv/100)*100 +1;
                    maxvv = ceil(vv/100)*100;
                    if maxvv<minvv
                        maxvv = ceil((vv+1)/100)*100;
                    end
                end
                Raw_wave = Raw_wave(minvv:min(maxvv, length(Raw_wave)));
                load(DataFile,'Piezo_wave', 'AudioLogs',   'Piezo_FS',  'FS', 'DiffRMS', 'RMSLow','VocFilename');
            end
        end
    end
        Fns_AL = fieldnames(Piezo_wave);
        
        % parameters
        Consecutive_binsMic = 10; % Number of consecutive bins of the envelope difference between highpass and low pass logger signal that has to be higher than threshold to be considered as a vocalization
        Consecutive_binsPiezo = 15; % Number of consecutive bins of the envelope difference between highpass and low pass logger signal that has to be higher than threshold to be considered as a vocalization
        Factor_RMS_low = 1.5.*ones(length(AudioLogs),1); % Factor by which the RMS of the low-pass filtered baseline signal is multiplied to obtained the threshold of vocalization detection on piezos
        Factor_AmpDiff = 50; % Factor by which the ratio of amplitude between low and high  pass filtered baseline signals is multiplied to obtain the threshold on calling vs hearing (when the bats call there is more energy in the lower frequency band than higher frequency band of the piezo) % used to be 3
        DB_noise = 60; % Noise threshold for the spectrogram colormap
        FHigh_spec = 90000; % Max frequency (Hz) for the raw data spectrogram
        FHigh_spec_Logger = 10000; % Max frequency (Hz) for the raw data spectrogram
        BandPassFilter = [1000 5000 9900]; % Frequency bands chosen for digital signal processing
        Fhigh_power =50; % Frequency upper bound for calculating the envelope (time running RMS)
        Fs_env = 1000; % Sample frequency of the enveloppe
        
        if df==1 || ~exist('sos_raw_band', 'var')
            % design filters of raw ambient recording, bandpass and low pass which was
            % used for the cross correlation
            [z,p,k] = butter(6,[BandPassFilter(1) 90000]/(FS/2),'bandpass');
            sos_raw_band = zp2sos(z,p,k);
            % [z,p,k] = butter(6,BandPassFilter(1:2)/(FS/2),'bandpass');
            % sos_raw_low = zp2sos(z,p,k);
            [z,p,k] = butter(6,[100 20000]/(FS/2),'bandpass');
            sos_raw_band_listen = zp2sos(z,p,k);
        end
        
        
        if df==1 || ~exist('sos_raw_band_listen', 'var')
            % design filters of raw ambient recording, bandpass, for
            % listening
            [z,p,k] = butter(6,[100 20000]/(FS/2),'bandpass');
            sos_raw_band_listen = zp2sos(z,p,k);
        end
        
        % Initialize variables

        if vv==1 % We need to initialize variables!
            IndVocStart_all = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc) a cell array of the size the number of loggers+microphone and for each logger the index onset of when the animal start vocalizing in the piezo recording before merge in envelope unit (FS_env)
            IndVocStop_all = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc) a cell array of the size the number of loggers and for each logger the index offset of when the animal start vocalizing in the piezo recording before merge in envelope unit (FS_env)
            IndVocStartRaw = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc)
            % a cell array of the size the number of loggers + 1 in case only one bat without a logger
            % or +2 incase no identification possible but you want to keep onset/offset of each voc and
            % for each logger the index onset of when the animal start vocalizing in the raw recording before merge
            IndVocStartPiezo = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc) a cell array of the size the number of loggers and for each logger the index onset of when the animal start vocalizing in the piezo recording before merge
            IndVocStopRaw = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc) a cell array of the size the number of loggers and for each logger the index offset of when the animal stop vocalizingin the raw recording before merge
            IndVocStopPiezo = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc) a cell array of the size the number of loggers and for each logger the index offset of when the animal stop vocalizingin the piezo recording before merge
            IndVocStartRaw_merged = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc) a cell array of the size the number of loggers and for each logger the index onset of when the animal start vocalizing in the raw recording
            IndVocStopRaw_merged = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc) a cell array of the size the number of loggers and for each logger the index offset of when the animal stop vocalizingin the raw recording
            IndVocStartPiezo_merged = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc) a cell array of the size the number of loggers and for each logger the index onset of when the animal start vocalizing in the piezo recording
            IndVocStopPiezo_merged = cell(1,Nvoc);% Contains for each sequence of vocalizations (Nvoc) a cell array of the size the number of loggers and for each logger the index offset of when the animal stop vocalizingin the piezo recording
            RMSRatio_all = cell(1,Nvoc);
            RMSDiff_all = cell(1,Nvoc);
            MicError = [0 0];% first element = number of corrections. second = number of detection (question)
            MicErrorType = [0 0];% first element false negative (detected as noise or already detected when it is a new call), second element false positive (vice versa)
            PiezoError = [0 0];% first element = number of corrections. second = number of detection (question)
            PiezoErrorType = [0 0]; % first element false negative (detected as noise or hearing when it is a new call), second element false positive (vice versa)
            
        end
end

FhGUI=CallCuraGui;
%set (FhGUI, 'position', [6.8000   36.4615  153.4000   43.7692]);
evalLog1h=findobj(FhGUI,'tag','evalLog1');
evalLog2h=findobj(FhGUI,'tag','evalLog2');
evalLog3h=findobj(FhGUI,'tag','evalLog3');
evalLog4h=findobj(FhGUI,'tag','evalLog4');
evalLog5h=findobj(FhGUI,'tag','evalLog5');
evalLog6h=findobj(FhGUI,'tag','evalLog6');
evalLog7h=findobj(FhGUI,'tag','evalLog7');
evalLog8h=findobj(FhGUI,'tag','evalLog8');
leftPloth=findobj(FhGUI,'tag','leftPlot');


