function CallCurafkt(action)
global vv F1 Nvoc df redoh redo DataFiles;
global L1 L2 L3 L4 L5 L6 L7 L8;

switch action
    
    case 'NoCall'
        fprintf(1,'Manual input enforced: Noise (=NoCall)\n');
        fprintf(1,'saving data...\n')
        savingData
        clf(F1)
        vv=vv+1;
        if vv<=Nvoc
            loadnextfile(vv)
        else
            eraseData
            if df<=length(DataFiles)
                grabNewDatafile(df)
                loadnextfile(vv)
            else
                fprintf(1,'Annotation done!\n');
            end
        end
    case 'Redo'
        oldvv=vv-1;
        olddf=df;
        %grab which file to reevaluate
        redostr=get(redoh,'string');
        redo_indx=strfind(redostr,'/');
        df=str2num(redostr(1:redo_indx-1));
        vv=str2num(redostr(redo_indx+1:end));
        if vv>Nvoc || df>length(DataFiles)
            fprintf(1,'Incorrect vv or df #\n');
        else
            fprintf(1,'Redo evaluation\n');
            fprintf(1,['Grabbing ' redostr '\n']);
            clf(F1)
            if df~=olddf
                grabNewDatafile(df)
            end
            loadnextfile(vv)
            redo=1;
            vv=oldvv;
            df=olddf;
        end
        
    case 'Submit'
        %save submit
        evaluationDone(vv)
        savingData
        %load next file
        vv=vv+1;
        if vv<=Nvoc
            loadnextfile(vv)
        else
            eraseData
            if df<=length(DataFiles)
                grabNewDatafile(df)
                loadnextfile(vv)
            else
                fprintf(1,'Annotation done!\n');
            end
        end
        
    case 'EvalLog1'
        evaluatingCalls(vv,1)
    case 'EvalLog2'
        evaluatingCalls(vv,2)
    case 'EvalLog3'
        evaluatingCalls(vv,3)
    case 'EvalLog4'
        evaluatingCalls(vv,4)
    case 'EvalLog5'
        evaluatingCalls(vv,5)
    case 'EvalLog6'
        evaluatingCalls(vv,6)
    case 'EvalLog7'
        evaluatingCalls(vv,7)
    case 'EvalLog8'
        evaluatingCalls(vv,8)
    case 'Quit'
        
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function loadnextfile(vv)
global Nvoc df DataFiles AudioLogs Amp_env_LowPassLogVoc;
global evalLog1h evalLog2h evalLog3h evalLog4h evalLog5h evalLog6h evalLog7h evalLog8h;

fprintf(1,'\n\n\n\nVoc sequence %d/%d Set %d/%d\n',vv,Nvoc, df, length(DataFiles));
checkforerror(vv)
grabAmbientMic(vv)
grabLoggers(vv)
prepfindCaller(vv)
% No logger data, just isolate onset/offset of vocalizations on the microphone
if sum(cellfun('isempty',(Amp_env_LowPassLogVoc))) == length(AudioLogs)
    fprintf(1,'CANNOT DETERMINE OWNERSHIP NO DETECTION OF ONSET/OFFSET\n')
    %ForceSaveOnOffSetMic(vv)
else
    DataOnLogger_prep
end
set([evalLog1h,evalLog2h,evalLog3h,evalLog4h,evalLog5h,evalLog6h,evalLog7h,evalLog8h],...
    'enable','on')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function savingData
global PreviousFile Working_dir_write Date ExpStartTime df MergeThresh vv;
global IndVocStartRaw_merged IndVocStopRaw_merged IndVocStartPiezo_merged;
global IndVocStopPiezo_merged IndVocStartRaw IndVocStopRaw IndVocStartPiezo;
global IndVocStopPiezo IndVocStart_all IndVocStop_all RMSRatio_all RMSDiff_all;
global MicError PiezoError MicErrorType PiezoErrorType SaveRawWave Raw_wave;

while 0
set([evalLog1h,evalLog2h,evalLog3h,evalLog4h,evalLog5h,evalLog6h,evalLog7h,evalLog8h],...
    'enable','off')
fprintf(1,'saving data...\n')
if ~isempty(dir(PreviousFile))
    save(fullfile(Working_dir_write, sprintf('%s_%s_VocExtractData%d_%d.mat', Date, ExpStartTime,df, MergeThresh)),...
        'IndVocStartRaw_merged', 'IndVocStopRaw_merged', 'IndVocStartPiezo_merged', ...
        'IndVocStopPiezo_merged', 'IndVocStartRaw', 'IndVocStopRaw', 'IndVocStartPiezo',...
        'IndVocStopPiezo', 'IndVocStart_all', 'IndVocStop_all','RMSRatio_all','RMSDiff_all',...
        'vv','MicError','PiezoError','MicErrorType','PiezoErrorType','-append');
else
    save(fullfile(Working_dir_write, sprintf('%s_%s_VocExtractData%d_%d.mat', Date, ExpStartTime,df, MergeThresh)),...
        'IndVocStartRaw_merged', 'IndVocStopRaw_merged', 'IndVocStartPiezo_merged',...
        'IndVocStopPiezo_merged', 'IndVocStartRaw', 'IndVocStopRaw', 'IndVocStartPiezo',...
        'IndVocStopPiezo', 'IndVocStart_all', 'IndVocStop_all','RMSRatio_all','RMSDiff_all',...
        'vv','MicError','PiezoError','MicErrorType','PiezoErrorType');
end
if SaveRawWave
    warning('Make sure you want to change that variable!! NOT recommended here as we are chuncking the loading!!!')
    keyboard
    save(DataFile, 'Raw_wave','-append')
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function grabNewDatafile
global df Nvocs Nvoc DataFile DataFiles PreviousFile Working_dir_write;
global Date ExpStartTime MergeThresh UseOld vv Loggers_dir Working_dir_read;
global Raw_wave  minvv  maxvv;
global Piezo_wave AudioLogs Piezo_FS FS DiffRMS RMSLow VocFilename;
global IndVocStartRaw_merged IndVocStopRaw_merged IndVocStartPiezo_merged;
global IndVocStopPiezo_merged IndVocStartRaw IndVocStopRaw IndVocStartPiezo;
global IndVocStopPiezo IndVocStart_all IndVocStop_all RMSRatio_all RMSDiff_all;
global MicError PiezoError MicErrorType PiezoErrorType;

df=df+1;
Nvoc = (df+1) - Nvocs(df);%not sure why this line?
DataFile = fullfile(DataFiles(df).folder, DataFiles(df).name);

PreviousFile = fullfile(Working_dir_write, sprintf('%s_%s_VocExtractData%d_%d.mat',...
    Date, ExpStartTime, df,MergeThresh));
if ~isfile(PreviousFile)
    PreviousFile = fullfile(Working_dir_write, sprintf('%s_%s_VocExtractData_%d.mat',...
        Date, ExpStartTime,MergeThresh));
end
if ~isempty(dir(PreviousFile)) && UseOld
    load(PreviousFile, 'IndVocStartRaw_merged', 'IndVocStopRaw_merged',...
        'IndVocStartPiezo_merged', 'IndVocStopPiezo_merged', ...
        'IndVocStart_all', 'IndVocStop_all','IndVocStartRaw',...
        'IndVocStopRaw', 'IndVocStartPiezo', 'IndVocStopPiezo',...
        'IndVocStart_all', 'IndVocStop_all','RMSRatio_all','RMSDiff_all',...
        'vv','MicError','PiezoError','MicErrorType','PiezoErrorType');
    % There is no previous data but just data regarding piezo numbers and bats_ID
    if ~exist('vv','var')
        vv=1;
    end
    
else
    vv=1;
end

if ~strcmp(Working_dir_write,Loggers_dir) && ~isfile(fullfile(Working_dir_read,DataFiles(df).name))
    fprintf(1,'Bringing data locally from the server\n')
    [s,m,e]=copyfile(DataFile, Working_dir_read, 'f');
    if ~s
        fprintf(1,'File transfer did not occur correctly\n')
        keyboard
    else
        DataFile = fullfile(Working_dir_read,DataFiles(df).name);
    end
end
load(DataFile,'Raw_wave')
if Nvoc ~= length(Raw_wave)
    warning('Looks like there might be an issue there!! Check variables!!')
    keyboard
end
if Nvoc<=100
    minvv = 1;
    maxvv = Nvoc;
    load(DataFile,'Piezo_wave', 'AudioLogs',   'Piezo_FS',  'FS', 'DiffRMS', 'RMSLow','VocFilename');
else % often problem of memory, we're going to chunck file loading
    if ~mod(vv,100)
        minvv=floor((vv-1)/100)*100 +1;
        maxvv=ceil(vv/100)*100;
    else
        minvv = floor(vv/100)*100 +1;
        maxvv = ceil(vv/100)*100;
        if maxvv<minvv
            maxvv = ceil((vv+1)/100)*100;
        end
    end
    Raw_wave = Raw_wave(minvv:min(maxvv, length(Raw_wave)));
    load(DataFile,'Piezo_wave', 'AudioLogs',   'Piezo_FS',  'FS', 'DiffRMS', 'RMSLow','VocFilename');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function eraseData
global DataFile SaveRawWave DataFiles df;
while 0
if SaveRawWave
    [s2,m,e]=copyfile(DataFile, fullfile(DataFiles(df).folder,DataFiles(df).name), 'f');
    if ~s2
        fprintf(1,'File transfer did not occur correctly\n')
        keyboard
    end
    if s2  %erase local data
        [sdel,mdel,edel]=rmdir(DataFile, 's');
    end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function checkforerror(vv)
global minvv maxvv Raw_wave DataFile Piezo_wave Raw_wave_nn;
global SaveRawWave VocFilename FS;

% Patch for previous error in the code
if vv<=maxvv
    Raw_wave_nn = Raw_wave{vv - (minvv -1)};
else
    clear Raw_wave Piezo_wave
    load(DataFile,'Raw_wave')
    if ~mod(vv,100)
        minvv=floor((vv-1)/100)*100 +1;
        maxvv=ceil(vv/100)*100;
    else
        minvv = floor(vv/100)*100 +1;
        maxvv = ceil(vv/100)*100;
        if maxvv<minvv
            maxvv = ceil((vv+1)/100)*100;
        end
    end
    Raw_wave = Raw_wave(minvv:min(maxvv, length(Raw_wave)));
    load(DataFile,'Piezo_wave')
    Raw_wave_nn = Raw_wave{vv - (minvv -1)};
end
if isempty(Raw_wave_nn)
    warning('That should not be empty now!!')
    keyboard
    SaveRawWave = 1;
    [Raw_wave{vv}, FS] = audioread(VocFilename{vv});
else
    SaveRawWave = 0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function grabAmbientMic(vv)
global DataFiles AudioLogs Raw_wave_nn Nvoc df sos_raw_band Amp_env_Mic;
global Filt_RawVoc FS Fhigh_power Fs_env DB_noise FHigh_spec ColorCode F1;
global Raw_Spec;
global leftPloth;

%% First calculate the time varying RMS of the ambient microphone
% bandpass filter the ambient mic recording
Filt_RawVoc = filtfilt(sos_raw_band,1,Raw_wave_nn);
Amp_env_Mic = running_rms(Filt_RawVoc, FS, Fhigh_power, Fs_env);
% Low passfilter the ambient mic recording (used for cross-correlation
% but not done anymore
%     LowPassMicVoc{vv} = filtfilt(sos_raw_low,1,Raw_wave{vv});
% Plot the spectrogram of the ambient microphone
axes(leftPloth)
F1=figure(1);
clf(F1)
ColorCode = [get(groot,'DefaultAxesColorOrder');1 1 1; 0 1 1; 1 1 0];
subplot(length(AudioLogs)+2,1,1)
[Raw_Spec.to, Raw_Spec.fo, Raw_Spec.logB] = spec_only_bats(Filt_RawVoc, FS, DB_noise, FHigh_spec);
hold on
yyaxis right
plot((1:length(Amp_env_Mic))/Fs_env*1000, Amp_env_Mic, 'r-', 'LineWidth',2)
ylabel(sprintf('Amp\nMic'))
title(sprintf('Voc %d/%d Set %d/%d',vv,Nvoc, df,length(DataFiles)))
xlabel(' ')
set(gca, 'XTick',[],'XTickLabel',{})
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function grabLoggers(vv)
global AudioLogs Piezo_wave Piezo_FS Fns_AL BandPassFilter;
global Fhigh_power Fs_env Amp_env_LowPassLogVoc;
global Amp_env_HighPassLogVoc leftPloth LowPassLogVoc;

Amp_env_LowPassLogVoc = cell(length(AudioLogs),1);
Amp_env_HighPassLogVoc = cell(length(AudioLogs),1);
LowPassLogVoc = cell(length(AudioLogs),1);
%% Loop through the loggers and check the extracts length
LengthLoggersData = nan(length(AudioLogs),1);
for ll=1:length(AudioLogs)
    LengthLoggersData(ll) = length(Piezo_wave.(Fns_AL{ll}){vv});
end
%% Loop through the loggers and calculate envelopes
for ll=1:length(AudioLogs)
    if isnan(Piezo_FS.(Fns_AL{ll})(vv)) || isempty(Piezo_wave.(Fns_AL{ll}){vv})
        fprintf(1, 'NO DATA for Vocalization %d from %s\n', vv, Fns_AL{ll})
    else
        % design the filters
        [z,p,k] = butter(6,BandPassFilter(1:2)/(Piezo_FS.(Fns_AL{ll})(vv)/2),'bandpass');
        sos_low = zp2sos(z,p,k);
        [z,p,k] = butter(6,BandPassFilter(2:3)/(Piezo_FS.(Fns_AL{ll})(vv)/2),'bandpass');
        sos_high = zp2sos(z,p,k);
        % filter the loggers' signals
        if sum(isnan(Piezo_wave.(Fns_AL{ll}){vv}))~=length(Piezo_wave.(Fns_AL{ll}){vv})
            % replace NaN by zeros so the filter can work and
            % check the length of extracts
            InputPiezo = Piezo_wave.(Fns_AL{ll}){vv};
            if sum(isnan(InputPiezo))
                InputPiezo(isnan(InputPiezo))=0;
                if length(InputPiezo)>min(LengthLoggersData)
                    warning('Piezo data have different durations!\n Logger %s data is truncated for analysis\n',Fns_AL{ll})
                    InputPiezo = InputPiezo(1:min(LengthLoggersData));
                end
                % low-pass filter the voltage trace
                LowPassLogVoc{ll} = (filtfilt(sos_low,1,InputPiezo));
                % high-pass filter the voltage trace
                HighPassLogVoc = (filtfilt(sos_high,1,InputPiezo));
            else
                if length(InputPiezo)>min(LengthLoggersData)
                    warning('Piezo data have different durations!\n Logger %s data is truncated for analysis\n',Fns_AL{ll})
                    InputPiezo = InputPiezo(1:min(LengthLoggersData));
                end
                % low-pass filter the voltage trace
                LowPassLogVoc{ll} = (filtfilt(sos_low,1,InputPiezo));
                % high-pass filter the voltage trace
                HighPassLogVoc = (filtfilt(sos_high,1,InputPiezo));
            end
            Amp_env_LowPassLogVoc{ll}=running_rms(LowPassLogVoc{ll}, ...
                Piezo_FS.(Fns_AL{ll})(vv), Fhigh_power, Fs_env);
            Amp_env_HighPassLogVoc{ll}=running_rms(HighPassLogVoc, ...
                Piezo_FS.(Fns_AL{ll})(vv), Fhigh_power, Fs_env);
            
            % Plot the low pass filtered signal of each logger
            axes(leftPloth)
            plotLogger(vv,ll,1,1)
            
            figure(ll+10)
            plotMic(vv,ll+10)
            plotLogger(vv,ll,ll+10,0)
        else
            Amp_env_LowPassLogVoc{ll}=resample(nan(1,length(Piezo_wave.(Fns_AL{ll}){vv})),...
                Fs_env, round(Piezo_FS.(Fns_AL{ll})(vv)));
            Amp_env_HighPassLogVoc{ll}=resample(nan(1,length(Piezo_wave.(Fns_AL{ll}){vv})),...
                Fs_env, round(Piezo_FS.(Fns_AL{ll})(vv)));
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function prepfindCaller(vv)
global DiffAmp AudioLogs CheckMicChannel RowSize;
global IndVocStartRaw IndVocStartPiezo IndVocStopRaw IndVocStopPiezo ;
global IndVocStart IndVocStop IndVocStartRaw_merge_local IndVocStopRaw_merge_local;
global IndVocStartPiezo_merge_local IndVocStopPiezo_merge_local;
global RMSRatio RMSDiff;
global Vocp;

%% Find out which calls are emitted by each individual,
%if checking the microphone is requested it means that a single animal did not
%have a collar and all microphone calls not detected on any piezo will be attributed to it
% This is the output of the decision criterion to determine at each time point
%if a bat is vocalizing or not. each row=a logger, each column = a time point
Vocp = nan(size(DiffAmp) + [1 0]);
if CheckMicChannel
    RowSize = length(AudioLogs) +1;
else
    RowSize = length(AudioLogs);
end
IndVocStartRaw{vv} = cell(RowSize,1);
IndVocStartPiezo{vv} = cell(RowSize,1);
IndVocStopRaw{vv} = cell(RowSize,1);
IndVocStopPiezo{vv} = cell(RowSize,1);
IndVocStart = cell(RowSize,1);
IndVocStop = cell(RowSize,1);
IndVocStartRaw_merge_local = cell(RowSize,1);
IndVocStopRaw_merge_local = cell(RowSize,1);
IndVocStartPiezo_merge_local = cell(RowSize,1);
IndVocStopPiezo_merge_local = cell(RowSize,1);
RMSRatio = cell(RowSize,1);
RMSDiff = cell(RowSize,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DataOnLogger_prep
global Amp_env_LowPassLogVoc Amp_env_HighPassLogVoc;
global AudioLogs ColorCode Fns_AL Factor_AmpDiff DiffRMS BandPassFilter;
global Factor_RMS_low RMSLow;
global DiffAmp RatioAmp;
global Amp_env_LowPassLogVoc_MAT Amp_env_HighPassLogVoc_MAT F2;


%% There is some data on the logger, extract the id of the vocalizing bat
% Treat the case where some approximations of the calculations led to
% slight diffreent sizes of running RMS
Short = min(cellfun('length',Amp_env_LowPassLogVoc));
Long = max(cellfun('length',Amp_env_LowPassLogVoc));
if (Long-Short)>1
    error('The length of vectors of running RMS are too different than expected, please check!\n')
elseif Long~=Short
    Amp_env_LowPassLogVoc = cellfun(@(X) X(1:Short), Amp_env_LowPassLogVoc, 'UniformOutput',false);
    Amp_env_HighPassLogVoc = cellfun(@(X) X(1:Short), Amp_env_HighPassLogVoc, 'UniformOutput',false);
end
Amp_env_LowPassLogVoc_MAT = cell2mat(Amp_env_LowPassLogVoc);
Amp_env_HighPassLogVoc_MAT = cell2mat(Amp_env_HighPassLogVoc);
RatioAmp = (Amp_env_LowPassLogVoc_MAT +1)./(Amp_env_HighPassLogVoc_MAT+1);
DiffAmp = Amp_env_LowPassLogVoc_MAT-Amp_env_HighPassLogVoc_MAT;

% Plot the ratio of time varying RMS, the difference in time varying
% RMS between the high and low frequency bands and the absolute time
% varying RMS of the low frequency band

F2=figure(2);
clf(F2)
subplot(3,1,3)
for ll=1:length(AudioLogs)
    plot(RatioAmp(ll,:), 'LineWidth',2, 'Color', ColorCode(ll,:))
    hold on
end
ylabel('Frequency bands Ratio')
legend(Fns_AL{:})
subplot(3,1,2)
for ll=1:length(AudioLogs)
    plot(DiffAmp(ll,:), 'LineWidth',2, 'Color', ColorCode(ll,:))
    hold on
end
title('Calling vs Hearing')
ylabel('Frequency bands Diff')
hold on
for ll=1:length(AudioLogs)
    plot([0 size(Amp_env_LowPassLogVoc_MAT,2)], Factor_AmpDiff * DiffRMS.(Fns_AL{ll})(1)*ones(2,1),...
        'Color',ColorCode(ll,:),'LineStyle','--');
    hold on
end
legend({Fns_AL{:} 'calling detection threshold' 'calling detection threshold'})
subplot(3,1,1)
for ll=1:length(AudioLogs)
    plot(Amp_env_LowPassLogVoc_MAT(ll,:), 'LineWidth',2, 'Color', ColorCode(ll,:))
    hold on
end
hold on
ylabel(sprintf('Running RMS %dHz-%dHz', BandPassFilter(1:2)))
title('Detection of vocalizations on each logger')
for ll=1:length(AudioLogs)
    plot([0 size(Amp_env_LowPassLogVoc_MAT,2)], Factor_RMS_low(ll) * RMSLow.(Fns_AL{ll})(1)*ones(2,1),...
        'Color',ColorCode(ll,:),'LineStyle','--');
    hold on
end


legend({Fns_AL{:} 'Microphone' 'voc detection threshold' 'voc detection threshold'})
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function CallOnLogger(ll)
global DiffAmp Fns_AL IndVocStart IndVocStop FHigh_spec_Logger FHigh_spec Fhl;
global RatioAmp RMSRatio RMSDiff Amp_env_LowPassLogVoc_MAT Factor_RMS_low RMSLow;
global Vocp Consecutive_binsPiezo Factor_AmpDiff DiffRMS Fs_env Call1Hear0_temp;

% Time points above amplitude threshold on the low-passed logger signal
Vocp(ll,:) = Amp_env_LowPassLogVoc_MAT(ll,:)>(Factor_RMS_low(ll) * RMSLow.(Fns_AL{ll})(1));
%find the first indices of every sequences of length "Consecutive_bins" higher than RMS threshold
IndVocStart{ll} = strfind(Vocp(ll,:), ones(1,Consecutive_binsPiezo));
if isempty(IndVocStart{ll})
    fprintf('\nNo vocalization detected on %s\n',Fns_AL{ll});
else% Some vocalizations were detected
    IndVocStart_diffind = find(diff(IndVocStart{ll})>1);
    % these two lines get rid of overlapping sequences that werer detected several times
    IndVocStart{ll} = [IndVocStart{ll}(1) IndVocStart{ll}(IndVocStart_diffind +1)];
    % This is the number of detected potential vocalization
    NV = length(IndVocStart{ll});
    IndVocStop{ll} = nan(1,NV);
    RMSRatio{ll} = nan(NV,1);
    RMSDiff{ll} = nan(NV,1);
    Call1Hear0_temp = nan(NV,1);
    
    
    for ii=1:NV
        IVStop = find(Vocp(ll,IndVocStart{ll}(ii):end)==0, 1, 'first');
        if ~isempty(IVStop)
            IndVocStop{ll}(ii) = IndVocStart{ll}(ii) + IVStop -1;
        else
            IndVocStop{ll}(ii) = length(Vocp(ll,:));
        end
        
        % Calculate the Average RMS Ratio for each sound extract
        % and decide about the vocalization ownership
        RMSRatio{ll}(ii) = mean(RatioAmp(ll,IndVocStart{ll}(ii):IndVocStop{ll}(ii)));
        RMSDiff{ll}(ii) = mean(DiffAmp(ll,IndVocStart{ll}(ii):IndVocStop{ll}(ii)));
        Call1Hear0_temp(ii) = RMSDiff{ll}(ii) > Factor_AmpDiff * DiffRMS.(Fns_AL{ll})(1);
        
        % update figure(3) with the decision
        Fhl=figure(10+ll);
        yyaxis right
        hold on
        if Call1Hear0_temp(ii)
            %computer guess is calling
            subplot(2,1,2);line([IndVocStart{ll}(ii)/Fs_env IndVocStop{ll}(ii)/Fs_env]*1000,...
                [FHigh_spec_Logger FHigh_spec_Logger]-2e3,'linewidth',20,'color',[0.8 0 .7])
        else
            %computer guess is hearing/noise
            subplot(2,1,1);line([IndVocStart{ll}(ii)/Fs_env IndVocStop{ll}(ii)/Fs_env]*1000,...
                [FHigh_spec FHigh_spec]-2e3,'linewidth',20,'color',[0 0.8 .7])
        end
        hold off
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function evaluatingCalls(vv,ll)
global IndVocStart Fs_env IndVocStop FHigh_spec_Logger;
global arrowfieldl arrowfieldr arrowfieldd arrowfieldu;
global Call1Hear0_temp PiezoError PiezoErrorType ManCall;

CallOnLogger(ll)
NV = length(IndVocStart{ll});
Call1Hear0_man = nan(NV,1);
figure(10+ll)
subplot(2,1,2)
hold on;
xlims=xlim;
ylims=ylim;
plot([xlims(end)-.1*xlims(end) xlims(end)],...
    [ylims(1)+.1*ylims(1) ylims(1)+.1*ylims(1)],'g','LineWidth',50)
text(xlims(end)-.07*xlims(end),ylims(1)+.1*ylims(1),'V','fontsize',30)
arrowfieldl=xlims(end)-.1*xlims(end);
arrowfieldr=xlims(end);
arrowfieldu=ylims(1);
arrowfieldd=ylims(1)+.1*ylims(1);
clickxv=xlims(1);
clickyv=ylims(end);
while clickxv<arrowfieldl || ...
        clickyv>= arrowfieldu
    [clickxv,clickyv]=ginput(1);
    check=1;
    ii=0;
    while check && ii<NV
        ii=ii+1;
        if clickxv>=(IndVocStart{ll}(ii)/Fs_env)*1e3  && clickxv<=(IndVocStop{ll}(ii)/Fs_env)*1e3
            if clickyv<FHigh_spec_Logger
                Call1Hear0_man(ii)=1;
            end
            ManCall=1;
            check=0;
        end
    end
    Agree = Call1Hear0_temp(ii)== Call1Hear0_man(ii);
    if ~Agree
        Call1Hear0_temp(ii) = Call1Hear0_man(ii);
        PiezoError = PiezoError + [1 1];
        PiezoErrorType = PiezoErrorType + [Call1Hear0_temp(ii) ~Call1Hear0_temp(ii)];
    else
        PiezoError = PiezoError + [0 1];
    end
end
updateLoggerEval(vv,ll)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function evaluationDone(vv)
global AudioLogs;
global IndVocStart IndVocStop IndVocStartRaw_merge_local IndVocStopRaw_merge_local;
global IndVocStartPiezo_merge_local IndVocStopPiezo_merge_local Fns_AL;
global RMSRatio RMSDiff Working_dir_write df MergeThresh;
global ManCall F1 F2 SaveFileType VocFilename Fhl;
global IndVocStartRaw_merged IndVocStopRaw_merged IndVocStartPiezo_merged;
global IndVocStopPiezo_merged IndVocStart_all IndVocStop_all RMSRatio_all RMSDiff_all;

figure(1)
subplot(length(AudioLogs)+2,1,1)
XLIM = get(gca, 'XLim');
subplot(length(AudioLogs)+2,1,length(AudioLogs)+2)
set(gca, 'YTick', 1:length(AudioLogs))
set(gca, 'YTickLabel', [Fns_AL; 'Mic'])
set(gca, 'YLim', [0 length(AudioLogs)+1])
set(gca, 'XLim', XLIM);
ylabel('AL ID')
xlabel('Time (ms)')
[~,FileVoc]=fileparts(VocFilename{vv});

while 0
if strcmp(SaveFileType,'pdf')
    if ManCall % Only save the RMS and spectro figures if there was a vocalization
        fprintf(1,'saving figures...\n')
        print(F1,fullfile(Working_dir_write,sprintf('%s_%d_%d_whocalls_spec_%d.pdf',...
            FileVoc,vv, df,MergeThresh)),'-dpdf','-fillpage')
        saveas(F2,fullfile(Working_dir_write,sprintf('%s_%d_%d_whocalls_RMS_%d.pdf',...
            FileVoc,vv, df,MergeThresh)),'pdf')
    end
elseif strcmp(SaveFileType,'fig')
    if ManCall % Only save the RMS and spectro figures if there was a vocalization
        fprintf(1,'saving figures...\n')
        saveas(F1,fullfile(Working_dir_write,sprintf('%s_%d_%d_whocalls_spec_%d.fig',...
            FileVoc,vv, df,MergeThresh)))
        saveas(F2,fullfile(Working_dir_write,sprintf('%s_%d_%d_whocalls_RMS_%d.fig',...
            FileVoc,vv, df,MergeThresh)))
    end
end
end
clf(F1)
clf(F2)
clf(Fhl)

% Gather Vocalization production data:
IndVocStart_all{vv} = IndVocStart;
IndVocStop_all{vv} = IndVocStop;
IndVocStartRaw_merged{vv} = IndVocStartRaw_merge_local;
IndVocStopRaw_merged{vv} = IndVocStopRaw_merge_local;
IndVocStartPiezo_merged{vv} = IndVocStartPiezo_merge_local;
IndVocStopPiezo_merged{vv} = IndVocStopPiezo_merge_local;
RMSRatio_all{vv} = RMSRatio;
RMSDiff_all{vv} = RMSDiff;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function updateLoggerEval(vv,ll)
global AudioLogs ManCall Call1Hear0_temp;
global IndVocStartRaw IndVocStartPiezo IndVocStopRaw IndVocStopPiezo ;
global IndVocStart IndVocStop IndVocStartRaw_merge_local IndVocStopRaw_merge_local;
global IndVocStartPiezo_merge_local IndVocStopPiezo_merge_local Fns_AL;
global ColorCode FS Piezo_FS;
global Fs_env MergeThresh;

if ManCall
    % Stash noise and Only keep vocalizations that were produced by the bat
    % according to the high RMSRatio value
    IndVocStart{ll} = IndVocStart{ll}(logical(Call1Hear0_temp));
    IndVocStop{ll} = IndVocStop{ll}(logical(Call1Hear0_temp));
    IndVocStartRaw{vv}{ll} = round(IndVocStart{ll}/Fs_env*FS);
    IndVocStartPiezo{vv}{ll} = round(IndVocStart{ll}/Fs_env*Piezo_FS.(Fns_AL{ll})(vv));
    IndVocStopRaw{vv}{ll} = round(IndVocStop{ll}/Fs_env*FS);
    IndVocStopPiezo{vv}{ll} = round(IndVocStop{ll}/Fs_env*Piezo_FS.(Fns_AL{ll})(vv));
    NV = sum(Call1Hear0_temp);
    
    if NV
        % Now merge detected vocalizations that are within MergeThresh
        Merge01 = (IndVocStart{ll}(2:end)-IndVocStop{ll}(1:(end-1)) < (MergeThresh/1000*Fs_env));
        NV = NV-sum(Merge01);
        IndVocStartRaw_merge_local{ll} = nan(1,NV);
        IndVocStopRaw_merge_local{ll} = nan(1,NV);
        IndVocStartPiezo_merge_local{ll} = nan(1,NV);
        IndVocStopPiezo_merge_local{ll} = nan(1,NV);
        CutInd = find(~Merge01);
        IndVocStartRaw_merge_local{ll}(1) = round(IndVocStart{ll}(1)/Fs_env*FS);
        IndVocStartPiezo_merge_local{ll}(1) = round(IndVocStart{ll}(1)/Fs_env*Piezo_FS.(Fns_AL{ll})(vv));
        IndVocStopRaw_merge_local{ll}(end) = round(IndVocStop{ll}(end)/Fs_env*FS);
        IndVocStopPiezo_merge_local{ll}(end) = round(IndVocStop{ll}(end)/Fs_env*Piezo_FS.(Fns_AL{ll})(vv));
        for cc=1:length(CutInd)
            IndVocStopRaw_merge_local{ll}(cc) = round(IndVocStop{ll}( CutInd(cc))/Fs_env*FS);
            IndVocStopPiezo_merge_local{ll}(cc) = round(IndVocStop{ll}(CutInd(cc))/Fs_env*Piezo_FS.(Fns_AL{ll})(vv));
            IndVocStartRaw_merge_local{ll}(cc+1) = round(IndVocStart{ll}(CutInd(cc)+1)/Fs_env*FS);
            IndVocStartPiezo_merge_local{ll}(cc+1) = round(IndVocStart{ll}(CutInd(cc)+1)/Fs_env*Piezo_FS.(Fns_AL{ll})(vv));
        end
        
        % Now plot the onset/offset of each extract on the
        % spectrograms of the loggers
        figure(1)
        for ii=1:NV
            subplot(length(AudioLogs)+2,1,ll+1)
            hold on
            yyaxis right
            YLim = get(gca, 'YLim');
            plot([IndVocStartRaw_merge_local{ll}(ii) IndVocStopRaw_merge_local{ll}(ii)]/FS*1000,...
                [YLim(2)*4/5 YLim(2)*4/5], 'k-', 'LineWidth',2)
            subplot(length(AudioLogs)+2,1,length(AudioLogs)+2)
            hold on
            plot([IndVocStartRaw_merge_local{ll}(ii) IndVocStopRaw_merge_local{ll}(ii)]/FS*1000,...
                [ll ll], 'Color',ColorCode(ll,:), 'LineWidth',2, 'LineStyle','-')
            hold off
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function plotMic(vv,FigN)
global Raw_Spec Fs_env IndVocStart IndVocStop Nvoc df DataFiles FHigh_spec;
global RowSize DB_noise;

figure(FigN)
subplot(2,1,1);
maxB = max(max(Raw_Spec.logB));
minB = maxB-DB_noise;
imagesc(Raw_Spec.to*1000,Raw_Spec.fo,Raw_Spec.logB);% to is in seconds
axis xy;
caxis('manual');
caxis([minB maxB]);
cmap = spec_cmap();
colormap(cmap);
v_axis = axis;
v_axis(3)=0;
v_axis(4)=FHigh_spec;
axis(v_axis);
xlabel('time (ms)'), ylabel('Frequency');
title(sprintf('Ambient Microphone Voc %d/%d Set %d/%d',vv,Nvoc,df,length(DataFiles)))
yyaxis right
hold on
yyaxis right
plot([IndVocStart{RowSize}(ii)/Fs_env IndVocStop{RowSize}(ii)/Fs_env]*1000, ...
    [RowSize RowSize], 'k:', 'LineWidth',2)
hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
function plotLogger(vv,ll,FigN,left)
global LowPassLogVoc Piezo_FS Fns_AL DB_noise FHigh_spec_Logger;
global Amp_env_LowPassLogVoc Amp_env_HighPassLogVoc Fs_env AudioLogs;

Figure(FigN)
if left
    subplot(length(AudioLogs)+2,1,ll+1)
else
    subplot(2,1,2);
end
[~] = spec_only_bats(LowPassLogVoc{ll}, Piezo_FS.(Fns_AL{ll})(vv), DB_noise, FHigh_spec_Logger);
hold on;
if left
    if ll<length(AudioLogs)
        xlabel(' '); % supress the x label output
        set(gca,'XTick',[],'XTickLabel',{});
    end
end
yyaxis right
plot((1:length(Amp_env_LowPassLogVoc{ll}))/Fs_env*1000,...
    Amp_env_LowPassLogVoc{ll}, 'b-','LineWidth', 2);
hold on
plot((1:length(Amp_env_HighPassLogVoc{ll}))/Fs_env*1000,...
    Amp_env_HighPassLogVoc{ll}, 'r-','LineWidth',2);
ylabel(sprintf('Amp\n%s',Fns_AL{ll}([1:3 7:end])))
hold off

